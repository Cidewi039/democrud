using MVC.Controllers;
namespace Test;


public class UnitTest1
{

    private readonly HomeController _home;

    public UnitTest1()
    {
        _home = new HomeController();

    }

    [Fact]
    public void Add_ShouldReturnCorrectSum()
    {


        int a = 5;
        int b = 3;


        int result = _home.Add(a, b);


        Assert.Equal(8, result);
    }

    [Fact]
    public void Subtract_ShouldReturnCorrectDifference()
    {
        // Arrange

        int num1 = 15;
        int num2 = 7;

        // Act
        int result = _home.Subtract(num1, num2);

        // Assert
        Assert.Equal(8, result);
    }

    [Fact]
    public void Multiply_ShouldReturnCorrectProduct()
    {
        // Arrange

        int num1 = 3;
        int num2 = 6;

        // Act
        int result = _home.Multiply(num1, num2);

        // Assert
        Assert.Equal(18, result);
    }

    [Fact]
    public void Divide_ShouldReturnCorrectQuotient()
    {
        // Arrange

        int num1 = 20;
        int num2 = 4;

        // Act
        int result = _home.Divide(num1, num2);

        // Assert
        Assert.Equal(5, result);
    }
        
         [Fact]
        public void Divide_ShouldThrowArgumentException_WhenDividingByZero()
        {
            // Arrange
            
            int num1 = 10;
            int num2 = 0;

            // Act & Assert
            Assert.Throws<ArgumentException>(() =>_home.Divide(num1, num2));
        }
    








}
